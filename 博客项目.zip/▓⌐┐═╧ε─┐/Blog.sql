/*
 Navicat Premium Data Transfer

 Source Server         : root
 Source Server Type    : MySQL
 Source Server Version : 80032
 Source Host           : localhost:3306
 Source Schema         : blog

 Target Server Type    : MySQL
 Target Server Version : 80032
 File Encoding         : 65001

 Date: 22/10/2023 15:54:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for blog
-- ----------------------------
DROP TABLE IF EXISTS `blog`;
CREATE TABLE `blog`  (
  `blog_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '博客id',
  `user_id` int(0) NOT NULL COMMENT '用户id',
  `blog_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '博客标题',
  `blog_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '博客内容',
  `blog_date` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '博客创建时间',
  `view_count` int(0) NOT NULL COMMENT '浏览量',
  `blog_likesid` int(0) NULL DEFAULT NULL COMMENT '点赞的表id',
  `blog_stepid` int(0) NULL DEFAULT NULL COMMENT '踩的表id',
  `evaluate_id` int(0) NULL DEFAULT NULL COMMENT '评论的表id',
  `label_id` int(0) NOT NULL COMMENT '标签的表id',
  `category_id` int(0) NOT NULL COMMENT '分类的表id',
  PRIMARY KEY (`blog_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1001015 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of blog
-- ----------------------------
INSERT INTO `blog` VALUES (1001001, 1003, '诗和远方', '那天,我看到了蘑菇云', '2023-03-12', 103, 1001001, 1001001, 1001001, 1001001, 1001001);
INSERT INTO `blog` VALUES (1001002, 1003, '机动战士高达', '那天,我也看到了蘑菇云', '2023-09-21', 134, 1001002, 1001002, 1001002, 1001002, 1001002);
INSERT INTO `blog` VALUES (1001003, 1002, '海绵宝宝观后感', '今天也有和派大星一起玩耍喔', '2023-07-20', 14340, 1001003, 1001003, 1001003, 1001003, 1001003);
INSERT INTO `blog` VALUES (1001004, 1001, '想去海边玩', '好热的夏天,好想去玩', '2023-7-18', 563, 1001004, 1001004, 1001004, 1001004, 1001004);
INSERT INTO `blog` VALUES (1001005, 1003, 'java教程', '下面总结在SimpleDateFormat中各个字母的意思  SimpleDateFormat函数变量/模式字母 G 年代标志符 y 年 M 月 d 日 h 时 在上午或下午 (1~12) H 时 在一天中 (0~23) m 分 s 秒 S 毫秒 E 星期 D 一年中的第几天 F 一月中第几个星期几 w 一年中第几个星期 W 一月中第几个星期 a 上午 / 下午 标记符 k 时 在一天中 (1~24) K 时 在上午或下午 (0~11) z 时区', '2023-10-19', 238, 1001005, 1001005, 1001005, 1001004, 1001004);
INSERT INTO `blog` VALUES (1001006, 1003, 'Java时间格式化最全总结', '下面总结在SimpleDateFormat中各个字母的意思  SimpleDateFormat函数变量/模式字母 G 年代标志符 y 年 M 月 d 日 h 时 在上午或下午 (1~12) H 时 在一天中 (0~23) m 分 s 秒 S 毫秒 E 星期 D 一年中的第几天 F 一月中第几个星期几 w 一年中第几个星期 W 一月中第几个星期 a 上午 / 下午 标记符 k 时 在一天中 (1~24) K 时 在上午或下午 (0~11) z 时区', '2023-10-19', 244, 1001006, 1001006, 1001006, 1001001, 1001003);
INSERT INTO `blog` VALUES (1001007, 1001007, 'CSS 教程', 'CSS (Cascading Style Sheets，层叠样式表），是一种用来为结构化文档（如 HTML 文档或 XML 应用）添加样式（字体、间距和颜色等）的计算机语言，CSS 文件扩展名为 .css。  通过使用 CSS 我们可以大大提升网页开发的工作效率！', '2023-10-19', 8, 1001007, 1001007, 1001007, 1001001, 1001003);
INSERT INTO `blog` VALUES (1001008, 1001007, '高达', '下面总结在SimpleDateFormat中各个字母的意思  SimpleDateFormat函数变量/模式字母 G 年代标志符 y 年 M 月 d 日 h 时 在上午或下午 (1~12) H 时 在一天中 (0~23) m 分 s 秒 S 毫秒 E 星期 D 一年中的第几天 F 一月中第几个星期几 w 一年中第几个星期 W 一月中第几个星期 a 上午 / 下午 标记符 k 时 在一天中 (1~24) K 时 在上午或下午 (0~11) z 时区', '2023-10-19', 27, 1001008, 1001008, 1001008, 1001005, 1001003);
INSERT INTO `blog` VALUES (1001009, 1001013, '1234', '11111111', '2023-10-20', 35, 1001009, 1001009, 1001009, 1001004, 1001004);
INSERT INTO `blog` VALUES (1001010, 1001009, '三稚晚樱的博客', '先帝1创业2未半而中道3崩殂4', '2023-10-20', 8, 1001010, 1001010, 1001010, 1001006, 1001003);
INSERT INTO `blog` VALUES (1001011, 1001004, 'css', '下面总结在SimpleDateFormat中各个字母的意思  SimpleDateFormat函数变量/模式字母 G 年代标志符 y 年 M 月 d 日 h 时 在上午或下午 (1~12) H 时 在一天中 (0~23) m 分 s 秒 S 毫秒 E 星期 D 一年中的第几天 F 一月中第几个星期几 w 一年中第几个星期 W 一月中第几个星期 a 上午 / 下午 标记符 k 时 在一天中 (1~24) K 时 在上午或下午 (0~11) z 时区', '2023-10-20', 18, 1001011, 1001011, 1001011, 1001005, 1001005);
INSERT INTO `blog` VALUES (1001012, 1001003, '我是小马', '我是小马,不服干我', '2023-10-20', 15, 1001012, 1001012, 1001012, 1001001, 1001002);
INSERT INTO `blog` VALUES (1001013, 1001007, '要答辩了,好鸡冻', '社恐黄柏富在线社恐', '2023-10-21', 7, 1001013, 1001013, 1001013, 1001006, 1001005);
INSERT INTO `blog` VALUES (1001014, 1001004, '我也会写博客', '你的博客,没有我的好看', '2023-10-21', 7, 1001014, 1001014, 1001014, 1001005, 1001006);
INSERT INTO `blog` VALUES (1001015, 1003, '我也会写博客', '你的博客,没有我的好看', '2023-10-21', 13, 1001015, 1001015, 1001015, 1001006, 1001005);
INSERT INTO `blog` VALUES (1001016, 1001001, '我要写最长的博客', '先帝创业未半而中道崩殂，今天下三分，益州疲弊，此诚危急存亡之秋也。然侍卫之臣不懈于内，忠志之士忘身于外者，盖追先帝之殊遇，欲报之于陛下也。诚宜开张圣听，以光先帝遗德，恢弘志士之气，不宜妄自菲薄，引喻失义，以塞忠谏之路也。 宫中府中，俱为一体，陟罚臧否，不宜异同。若有作奸犯科及为忠善者，宜付有司论其刑赏，以昭陛下平明之理，不宜偏私，使内外异法也。 侍中、侍郎郭攸之、费祎、董允等，此皆良实，志虑忠纯，是以先帝简拔以遗陛下。愚以为宫中之事，事无大小，悉以咨之，然后施行，必能裨补阙漏，有所广益。 将军向宠，性行淑均，晓畅军事，试用于昔日，先帝称之曰能，是以众议举宠为督。愚以为营中之事，悉以咨之，必能使行阵和睦，优劣得所。 亲贤臣，远小人，此先汉所以兴隆也；亲小人，远贤臣，此后汉所以倾颓也。先帝在时，每与臣论此事，未尝不叹息痛恨于桓、灵也。侍中、尚书、长史、参军，此悉贞良死节之臣，愿陛下亲之信之，则汉室之隆，可计日而待也。 臣本布衣，躬耕于南阳，苟全性命于乱世，不求闻达于诸侯。先帝不以臣卑鄙，猥自枉屈，三顾臣于草庐之中，咨臣以当世之事，由是感激，遂许先帝以驱驰。后值倾覆，受任于败军之际，奉命于危难之间，尔来二十有一年矣。 先帝知臣谨慎，故临崩寄臣以大事也。受命以来，夙夜忧叹，恐托付不效，以伤先帝之明，故五月渡泸，深入不毛。今南方已定，兵甲已足，当奖率三军，北定中原········', '2023-10-22', 3, 1001016, 1001016, 1001016, 1001007, 1001002);

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `category_id` int(0) NOT NULL COMMENT '分类id',
  `category_name` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '分类名称'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1001004, '风景');
INSERT INTO `category` VALUES (1001003, '文化');
INSERT INTO `category` VALUES (1001002, '科幻');
INSERT INTO `category` VALUES (1001001, '想法');
INSERT INTO `category` VALUES (1001005, '作业');
INSERT INTO `category` VALUES (1001006, '抽象');

-- ----------------------------
-- Table structure for evaluate
-- ----------------------------
DROP TABLE IF EXISTS `evaluate`;
CREATE TABLE `evaluate`  (
  `evaluate_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '评论表id',
  `blog_id` int(0) NULL DEFAULT NULL COMMENT '博客id',
  `evaluate_content` varchar(160) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '评论内容',
  `user_id` int(0) NULL DEFAULT NULL COMMENT '评论者用户id',
  PRIMARY KEY (`evaluate_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1001029 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of evaluate
-- ----------------------------
INSERT INTO `evaluate` VALUES (1001003, 1001003, '海绵宝宝我也超喜欢看', 1005);
INSERT INTO `evaluate` VALUES (1001004, 1001004, '哈哈哈,我也想去海边,天气太热了', 1004);
INSERT INTO `evaluate` VALUES (1001005, 1001004, '抱歉捏,我这边四季如春', 1002);
INSERT INTO `evaluate` VALUES (1001006, 1001006, '不太懂捏', 1003);
INSERT INTO `evaluate` VALUES (1001007, 1001006, '学会了', 1001007);
INSERT INTO `evaluate` VALUES (1001008, 1001008, '哼好', 1001014);
INSERT INTO `evaluate` VALUES (1001009, 1001008, '你喜欢高达,好巧,我家高达会翻跟头', 1003);
INSERT INTO `evaluate` VALUES (1001010, 1001008, '不可能', 1001008);
INSERT INTO `evaluate` VALUES (1001011, 1001009, '乱写', 1001008);
INSERT INTO `evaluate` VALUES (1001012, 1001003, '章鱼哥要掉小珍珠咯', 1003);
INSERT INTO `evaluate` VALUES (1001013, 1001003, '举办了,刷浏览量,等亖吧', 1001009);
INSERT INTO `evaluate` VALUES (1001014, 1001004, '666', 1001004);
INSERT INTO `evaluate` VALUES (1001015, 1001004, '我不服,热门第一刷这么多浏览量', 1001);
INSERT INTO `evaluate` VALUES (1001016, 1001004, '傻狗刘能诚', 1001);
INSERT INTO `evaluate` VALUES (1001017, 1001011, '教教我荣耀二阶怎么打', 1001);
INSERT INTO `evaluate` VALUES (1001018, 1001011, '你会玩个吃屎', 1001004);
INSERT INTO `evaluate` VALUES (1001019, 1001010, '背的不全捏', 1001002);
INSERT INTO `evaluate` VALUES (1001020, 1001012, '你个狗', 1001009);
INSERT INTO `evaluate` VALUES (1001021, 1001012, '好啊', 1001012);
INSERT INTO `evaluate` VALUES (1001022, 1001012, '牛哇', 1001012);
INSERT INTO `evaluate` VALUES (1001023, 1001014, '夏天和西瓜绝配有没有', 1001017);
INSERT INTO `evaluate` VALUES (1001024, 1001011, '你个狗', 1003);
INSERT INTO `evaluate` VALUES (1001025, 1001013, '你在想什么,笨蛋', 1001001);
INSERT INTO `evaluate` VALUES (1001026, 1001015, '章鱼哥要掉小珍珠咯', 1001018);
INSERT INTO `evaluate` VALUES (1001028, 1001016, '挺好的，只是当年没背下来', 1001001);

-- ----------------------------
-- Table structure for label
-- ----------------------------
DROP TABLE IF EXISTS `label`;
CREATE TABLE `label`  (
  `label_id` int(0) NOT NULL COMMENT '标签表id',
  `label_name` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '标签名称'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of label
-- ----------------------------
INSERT INTO `label` VALUES (1001004, '海边');
INSERT INTO `label` VALUES (1001003, '动漫');
INSERT INTO `label` VALUES (1001002, '高达');
INSERT INTO `label` VALUES (1001001, '诗');
INSERT INTO `label` VALUES (1001005, '教程');
INSERT INTO `label` VALUES (1001006, '冷知识');
INSERT INTO `label` VALUES (1001007, '高山');
INSERT INTO `label` VALUES (1001008, '日出');
INSERT INTO `label` VALUES (1001009, '冷知识');

-- ----------------------------
-- Table structure for likes
-- ----------------------------
DROP TABLE IF EXISTS `likes`;
CREATE TABLE `likes`  (
  `blog_likesid` int(0) NOT NULL COMMENT '博客附表_点赞表id',
  `blog_likesuserid` int(0) NULL DEFAULT NULL COMMENT '点赞的用户id'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of likes
-- ----------------------------
INSERT INTO `likes` VALUES (1001003, 1003);
INSERT INTO `likes` VALUES (1001003, 1001004);
INSERT INTO `likes` VALUES (1001008, 1001004);
INSERT INTO `likes` VALUES (1001007, 1001004);
INSERT INTO `likes` VALUES (1001006, 1001009);
INSERT INTO `likes` VALUES (1001003, 1001009);
INSERT INTO `likes` VALUES (1001010, 1001009);
INSERT INTO `likes` VALUES (1001010, 1001004);
INSERT INTO `likes` VALUES (1001009, 1001004);
INSERT INTO `likes` VALUES (1001004, 1001004);
INSERT INTO `likes` VALUES (1001004, 1001);
INSERT INTO `likes` VALUES (1001006, 1001);
INSERT INTO `likes` VALUES (1001011, 1001);
INSERT INTO `likes` VALUES (1001011, 1001004);
INSERT INTO `likes` VALUES (1001011, 1001003);
INSERT INTO `likes` VALUES (1001012, 1001003);
INSERT INTO `likes` VALUES (1001003, 1001002);
INSERT INTO `likes` VALUES (1001012, 1001002);
INSERT INTO `likes` VALUES (1001006, 1001002);
INSERT INTO `likes` VALUES (1001011, 1001002);
INSERT INTO `likes` VALUES (1001010, 1001002);
INSERT INTO `likes` VALUES (1001012, 1001009);
INSERT INTO `likes` VALUES (1001012, 1001008);
INSERT INTO `likes` VALUES (1001012, 1001001);
INSERT INTO `likes` VALUES (1001003, 1001001);
INSERT INTO `likes` VALUES (1001012, 1001012);
INSERT INTO `likes` VALUES (1001013, 1001007);
INSERT INTO `likes` VALUES (1001014, 1001004);
INSERT INTO `likes` VALUES (1001002, 1001012);
INSERT INTO `likes` VALUES (1001006, 1001004);
INSERT INTO `likes` VALUES (1001013, 1001009);
INSERT INTO `likes` VALUES (1001014, 1001017);
INSERT INTO `likes` VALUES (1001011, 1001017);
INSERT INTO `likes` VALUES (1001011, 1003);
INSERT INTO `likes` VALUES (1001004, 1003);
INSERT INTO `likes` VALUES (1001015, 1003);
INSERT INTO `likes` VALUES (1001013, 1001001);
INSERT INTO `likes` VALUES (1001015, 1001018);
INSERT INTO `likes` VALUES (1001014, 1001018);
INSERT INTO `likes` VALUES (1001013, 1001018);
INSERT INTO `likes` VALUES (1001003, 1001018);
INSERT INTO `likes` VALUES (1001015, 1001001);
INSERT INTO `likes` VALUES (1001016, 1001001);

-- ----------------------------
-- Table structure for step
-- ----------------------------
DROP TABLE IF EXISTS `step`;
CREATE TABLE `step`  (
  `blog_stepid` int(0) NOT NULL COMMENT '博客附表_点赞表id',
  `blog_stepuserid` int(0) NULL DEFAULT NULL COMMENT '点踩的用户id'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of step
-- ----------------------------
INSERT INTO `step` VALUES (1001001, 1002);
INSERT INTO `step` VALUES (1001003, 1002);
INSERT INTO `step` VALUES (1001007, 1001008);
INSERT INTO `step` VALUES (1001013, 1001009);
INSERT INTO `step` VALUES (1001006, 1003);
INSERT INTO `step` VALUES (1001008, 1001007);
INSERT INTO `step` VALUES (1001005, 1003);
INSERT INTO `step` VALUES (1001009, 1001013);
INSERT INTO `step` VALUES (1001004, 1001);
INSERT INTO `step` VALUES (1001002, 1003);
INSERT INTO `step` VALUES (1001010, 1001004);
INSERT INTO `step` VALUES (1001012, 1001012);
INSERT INTO `step` VALUES (1001002, 1001012);
INSERT INTO `step` VALUES (1001014, 1001017);
INSERT INTO `step` VALUES (1001011, 1003);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `user_id` int(0) NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `user_name` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `user_password` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户密码',
  `user_phone` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户手机号',
  `user_email` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户邮箱',
  `user_status` int(0) NOT NULL COMMENT '用户权限,1为管理员,0为普通用户',
  `user_collect` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '用户个性签名',
  `user_introduce` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '注册时间',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1001018 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1001, '张作霖', '12345678', '17548765394', '36548722@qq.com', 0, '十里桃花,三生有幸', '2023-01-19');
INSERT INTO `user` VALUES (1002, '江秀愉', '12345678', '17347654872', '2324654212@qq.com', 0, '桃之夭夭,灼灼其华', '2023-04-16');
INSERT INTO `user` VALUES (1003, '毛开增', '12345678', '17376282349', '2135251033@qq.com', 0, '手机一扔,与世无争', '2023-06-02');
INSERT INTO `user` VALUES (1004, '刘德华', '12345678', '17548765394', '365422@qq.com', 0, '十里桃花,三生有幸', '2023-08-24');
INSERT INTO `user` VALUES (1005, '武盛', '12345678', '15647659871', '564574345@qq.com', 1, '武盛一个虎扑打烂整个聚窟洲', '2023-08-27');
INSERT INTO `user` VALUES (1001001, '三稚晚樱', '12345', '17638746532', '21352510331@qq.com', 1, '手机一扔,与世界无争', '2023-10-17');
INSERT INTO `user` VALUES (1001002, '钟漂亮', '12345678', '17376282349', '1474548340@qq.com', 0, '手机一扔,与世无争', '2023-10-19');
INSERT INTO `user` VALUES (1001003, '小马', '12345678', '15546738754', '3436488298@qq.com', 0, '傻狗小马', '2023-10-19');
INSERT INTO `user` VALUES (1001004, '刘能诚', '12345678', '13876549876', '23546655@qq.com', 0, '傻狗刘能诚', '2023-10-19');
INSERT INTO `user` VALUES (1001005, '吴贤昌', '12345678', '18756748934', '4235435@qq.com', 0, '男桐吴贤昌', '2023-10-19');
INSERT INTO `user` VALUES (1001007, '黄柏富', '12345678', '13546768954', '31432324@qq.com', 0, '粉色发色法', '2023-10-19');
INSERT INTO `user` VALUES (1001008, '三稚晚樱', '12345678', '17867589843', '43254224@qq.com', 0, '花开十里不多,红颜一人正好', '2023-10-19');
INSERT INTO `user` VALUES (1001009, '三稚晚樱', '12345678', '17867589843', '488944952@qq.com', 0, '七七八八', '2023-10-19');
INSERT INTO `user` VALUES (1001010, '三稚晚樱', '11111111', '17867589843', '48894495@qq.com', 0, '手机一扔,与世无争', '2023-10-20');
INSERT INTO `user` VALUES (1001011, '橘橘', '123456', '123456789', '123456@gmail.com', 0, '123', '2023-10-20');
INSERT INTO `user` VALUES (1001012, '牛马', '12345678', '1562654784', '1234422@qq.com', 0, '我giao', '2023-10-20');
INSERT INTO `user` VALUES (1001013, '橘橘', '123456', '123456789', '12345678@gmail.com', 0, '123', '2023-10-20');
INSERT INTO `user` VALUES (1001014, '吴某', '12345678', '12248537515', '122485375@qq.com', 0, '我在人性这方面确实不如你', '2023-10-20');
INSERT INTO `user` VALUES (1001015, '老徐', '12345678', '133452679780', '3415426781@qq.com', 0, '你看我像不像你', '2023-10-21');
INSERT INTO `user` VALUES (1001016, '韦品德', '12345678', '176898754', '54637654@qq.com', 0, '没有个性签名', '2023-10-21');
INSERT INTO `user` VALUES (1001017, '韦富', '12345678', '17658764598', '12345678@qq.com', 0, '我叫韦富', '2023-10-21');
INSERT INTO `user` VALUES (1001018, '韦富', '11111111', '17658764598', '321243212@qq.com', 0, '我叫韦富', '2023-10-21');

SET FOREIGN_KEY_CHECKS = 1;
