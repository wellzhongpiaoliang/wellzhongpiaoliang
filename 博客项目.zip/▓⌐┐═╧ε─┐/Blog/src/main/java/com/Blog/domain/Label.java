package com.Blog.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Label {

  private Integer labelId;  // 标签id
  private String labelName;  //标签名


}
