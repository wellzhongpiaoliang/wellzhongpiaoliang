package com.Blog.mapper;

import com.Blog.domain.Category;
import com.Blog.domain.Label;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/19 11:29
 */
public interface LabelAndCategoryMapper {

//    获取所有标签和分类
    List<Label> showLabel();

    List<Category> showCategory();
}
