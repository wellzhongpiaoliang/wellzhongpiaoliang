package com.Blog.config;

import com.Blog.interceptor.MyInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

/**
 * @author 14745
 * @date 2023/10/16 9:08
 * mvc配置文件
 */

@Configuration // 标记一个配置类,相当于配置文件
//扫描控制器
@ComponentScan({"com.Blog.controller"})
@EnableWebMvc
public class SpringMvcConfig implements WebMvcConfigurer{

//    Bean注解 实例化我们定义的拦截器交给spring管理
    @Bean
    public MyInterceptor testInterceptor() {
        return new MyInterceptor();
    }

//    静态资源放通
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable();
    }

//    配置前后缀
    public void configureViewResolvers(ViewResolverRegistry registry) {
        registry.jsp("/jsp/",".jsp");
    }

//    使用拦截器
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(testInterceptor()).addPathPatterns("/**");
    }

}
