package com.Blog.mapper;

import com.Blog.domain.Blog;
import com.Blog.domain.Category;
import com.Blog.domain.Evaluate;
import com.Blog.domain.Label;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/16 16:26
 */
public interface BlogMapper {
    //    添加博客
    int addBlog(Blog blog);

//    显示所有博客
    List<Blog> showBlog();

    //    根据博客id添加评论id
    int setEvaluateIdInt(Blog blog);

    //    根据id获取标签
    Label selectByLabelIdLabel(int id);

    //    根据id获取评论
    List<Evaluate> selectByEvaluateId(int id);

    //    根据id获取分类
    Category selectByCategoryId(int id);

    //    根据博客标题查找博客
    List<Blog> selectByTitleAndBlog(String title);

    //    根据博客id获取博客
    Blog selectBlogIdBlog(int id);


    //    根据评论id添加评论
    int addEvaluateContentInt(Evaluate evaluate);

    //    根据用户id查询博客
    List<Blog> selectByUserIdAndBlog(int id);

    //    获取热门博客
    List<Blog> selectHotBlog();

    //    增加浏览量
    int addBlogViewCount(@Param("count") int count, @Param("id") int id);

    //    博客修改
    int setBlog(Blog blog);
}
