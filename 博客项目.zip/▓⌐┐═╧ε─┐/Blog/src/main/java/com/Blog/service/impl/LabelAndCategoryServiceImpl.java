package com.Blog.service.impl;

import com.Blog.domain.Category;
import com.Blog.domain.Label;
import com.Blog.mapper.LabelAndCategoryMapper;
import com.Blog.service.LabelAndCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/19 11:33
 */
@Service
public class LabelAndCategoryServiceImpl implements LabelAndCategoryService{
    @Autowired
    private LabelAndCategoryMapper labelAndCategoryMapper;

    @Override
    public List<Label> showLabel() {
        return labelAndCategoryMapper.showLabel();
    }

    @Override
    public List<Category> showCategory() {
        return labelAndCategoryMapper.showCategory();
    }
}
