package com.Blog.mapper;

import com.Blog.domain.Blog;
import com.Blog.domain.Likes;
import com.Blog.domain.Step;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/18 10:54
 */
public interface LikesMapper {

    //    根据博客表存储的点赞id查询点赞的用户
    List<Likes> showLikes(int id);

    //    根据博客表存储的踩id查询踩的用户
    List<Step> showStep(int id);

    //    添加点赞id 该id等于博客id,都是独一无二的
    int setLikesId(Blog blog);

    //    添加踩id 该id等于博客id,都是独一无二的
    int setStepId(Blog blog);

    //    点赞累加 因为存储的是用户id,所以一个用户只能点赞一次
    int addLikes(@Param("LikesId") int LikesId,@Param("userId") int userId);

    //    踩累加 因为存储的是用户id,所以一个用户只能踩一次
    int addStep(@Param("StepId") int StepId,@Param("userId") int userId);

}
