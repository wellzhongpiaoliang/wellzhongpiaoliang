package com.Blog.service;

import com.Blog.domain.Blog;
import com.Blog.domain.Likes;
import com.Blog.domain.Step;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/18 10:55
 */
public interface LikesService {
    List<Likes> showLikes(int id);

    //    根据博客表存储的踩id查询踩的用户
    List<Step> showStep(int id);

    int setLikesId(Blog blog);

    int setStepId(Blog blog);

    //    点赞累加 因为存储的是用户id,所以一个用户只能点赞一次
    int addLikes(int LikesId,int userId);

    //    踩累加 因为存储的是用户id,所以一个用户只能踩一次
    int addStep(int StepId,int userId);

}
