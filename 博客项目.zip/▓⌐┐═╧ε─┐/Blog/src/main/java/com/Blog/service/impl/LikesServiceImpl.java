package com.Blog.service.impl;

import com.Blog.domain.Blog;
import com.Blog.domain.Likes;
import com.Blog.domain.Step;
import com.Blog.mapper.LikesMapper;
import com.Blog.service.LikesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/18 10:55
 */
@Service
public class LikesServiceImpl implements LikesService {
    @Autowired
    private LikesMapper likesMapper;
    @Override
    public List<Likes> showLikes(int id) {
        return likesMapper.showLikes(id);
    }

    @Override
    public List<Step> showStep(int id) {
        return likesMapper.showStep(id);
    }

    @Override
    public int setLikesId(Blog blog) {
        return likesMapper.setLikesId(blog);
    }

    @Override
    public int setStepId(Blog blog) {
        return likesMapper.setStepId(blog);
    }

    @Override
    public int addLikes(int LikesId,int userId) {
        return likesMapper.addLikes(LikesId,userId);
    }

    @Override
    public int addStep(int StepId,int userId) {
        return likesMapper.addStep(StepId,userId);
    }
}
