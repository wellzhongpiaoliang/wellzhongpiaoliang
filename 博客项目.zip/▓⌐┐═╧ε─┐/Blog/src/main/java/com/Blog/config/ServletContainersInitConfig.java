package com.Blog.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**
 * @author 14745
 * @date 2023/10/16 9:07
 * 和web.xml配置文件类似
 */
public class ServletContainersInitConfig extends AbstractAnnotationConfigDispatcherServletInitializer {

//   加载Spring配置类中的信息,初始化Spring容器
    protected Class<?>[] getRootConfigClasses() {
        return new Class[]{SpringConfig.class};
    }

//    加载SpringMVC配置类中的信息,初始化SpringMVC的容器
    protected Class<?>[] getServletConfigClasses() {
        return new Class[]{SpringMvcConfig.class};
    }

//    配置DispatcherServlet的映射路径
    protected String[] getServletMappings() {
        return new String[]{"/"};
    }
}
