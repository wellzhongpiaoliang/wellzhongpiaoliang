package com.Blog.interceptor;

import com.Blog.domain.User;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author 14745
 * @date 2023/10/16 9:24
 */
public class MyInterceptor extends HandlerInterceptorAdapter {

//    拦截未登录用户访问主页
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //获取session中的数据
        User u = (User) request.getSession().getAttribute("USER_SESSION");
//        System.out.println("获取sessionUser"+u);
        String uri = request.getRequestURI(); // 获取路径
        // 如果用户是已登录状态,放行
        if (u!=null){
            return true;
        }
        // 判断请求是否进行登录,登录则放行
        if (uri.contains("login")){
            return true;
        }
        // 判断请求是否进行注册,注册则放行
        if (uri.contains("addUser")){
            return true;
        }
        // 其他情况都直接跳转到登录页面
        request.setAttribute("msg","您还没有登录,请先登录");
        request.getRequestDispatcher("/jsp/login.jsp").forward(request,response);
        return false;
    }
}
