package com.Blog.controller;

import com.Blog.domain.*;
import com.Blog.service.BlogService;
import com.Blog.service.LikesService;
import com.Blog.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 14745
 * @date 2023/10/18 20:06
 */

// 评论控制,评论的添加
@Controller
@RequestMapping("/evaluate")
public class EvaluateController {
    @Autowired
    private BlogService blogService;
    @Autowired
    private UserService userService;
    @Autowired
    private LikesService likesService;

    //    添加评论
    @RequestMapping("/addEvaluate")
    public ModelAndView addEvaluate(HttpServletRequest request, Evaluate evaluates) {
        ModelAndView view = new ModelAndView();
//        评论者就是登录这个账号的用户
        User users = (User) request.getSession().getAttribute("USER_SESSION");
//        获取用户id
        evaluates.setUserId(users.getId());
//        有了用户id就可以添加评论
        int i1 = blogService.addEvaluateContentInt(evaluates);
        System.out.println(i1 > 0 ? "添加成功" : "添加失败");
//        前端传博客id回来进行查询
        Blog blog = blogService.selectBlogIdBlog(evaluates.getBlogId());
//        查询评论
        List<Evaluate> evaluate = blogService.selectByEvaluateId(blog.getBlogId());
        ArrayList<String> list = new ArrayList<>();
//        查询评论用户名
        for (int i = 0; i < evaluate.size(); i++) {
            User user = userService.selectByIdUser(evaluate.get(i).getUserId());
            list.add(user.getName());
        }
        //        查询博客所属人
        User user = userService.selectByIdUser(blog.getUserId());
//        查询标签
        Label label = blogService.selectByLabelIdLabel(blog.getLabelId());
//        查询分类
        Category category = blogService.selectByCategoryId(blog.getCategoryId());
//        查询点赞量
        List<Likes> likes = likesService.showLikes(blog.getBlogLikesid());
        List<Step> steps = likesService.showStep(blog.getBlogStepid());
        view.addObject("evaluate", evaluate);
        view.addObject("blog", blog);
        view.addObject("user", user);
        view.addObject("label", label);
        view.addObject("category", category);
        view.addObject("list", list);
        view.addObject("likes", likes.size());
        view.addObject("steps", steps.size());
        view.setViewName("/blogCenter");
        return view;
    }
}
