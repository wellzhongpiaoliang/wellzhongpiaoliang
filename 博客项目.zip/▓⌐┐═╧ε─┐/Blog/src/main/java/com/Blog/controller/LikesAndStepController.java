package com.Blog.controller;

import com.Blog.domain.Blog;
import com.Blog.domain.Likes;
import com.Blog.domain.Step;
import com.Blog.domain.User;
import com.Blog.mapper.LikesMapper;
import com.Blog.service.BlogService;
import com.Blog.service.LikesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.sql.SQLOutput;
import java.util.List;

/**
 * @author 14745
 * @date 2023/10/20 8:59
 */
//  点赞和踩的控制器
@Controller
public class LikesAndStepController {
    @Autowired
    private LikesService likesService;
    @Autowired
    private BlogService blogService;

    @RequestMapping("/addLikes")
    public String addLikes(HttpServletRequest request,User users, Blog blog) {
        User user = (User) request.getSession().getAttribute("USER_SESSION");
        //       如果存在高并发则需要更优的代码 获取浏览量并且+1
        Blog blogs = blogService.selectBlogIdBlog(blog.getBlogId());
        //        查询点赞者
        List<Likes> likes = likesService.showLikes(blogs.getBlogLikesid());
//        点赞不能添加访问量
        int sum = blogs.getViewCount() - 1;
        int i1 = blogService.addBlogViewCount(sum, blogs.getBlogId());
        for (int i = 0; i < likes.size(); i++) {
            int likesId = likes.get(i).getBlogLikesuserid();
            if (likesId == user.getId()) {
//                已经点赞过,返回页面
                return "forward:/blog/getByIdBlog?id=" + blog.getBlogId();
            }
        }
        int i = likesService.addLikes(blogs.getBlogLikesid(), user.getId());
        System.out.println(i > 0 ? "点赞成功" : "点赞失败");
        return "forward:/blog/getByIdBlog?id=" + blog.getBlogId();
//        return view;
    }

//    踩
    @RequestMapping("/addStep")
    public String addStep(HttpServletRequest request,User users, Blog blog) {
        //       如果存在高并发则需要更优的代码 获取浏览量并且+1
        Blog blogs = blogService.selectBlogIdBlog(blog.getBlogId());
        User user = (User) request.getSession().getAttribute("USER_SESSION");
        //        查询踩者
        List<Step> steps = likesService.showStep(blogs.getBlogStepid());
        int sum = blogs.getViewCount() - 1;
        int i1 = blogService.addBlogViewCount(sum, blogs.getBlogId());
        for (int i = 0; i < steps.size(); i++) {
            int StepId = steps.get(i).getBlogStepuserid();
            if (StepId==user.getId()) {
//                已经点赞过,返回页面
                return "forward:/blog/getByIdBlog?id=" + blog.getBlogId();
            }
        }
        int i = likesService.addStep(blogs.getBlogStepid(), user.getId());
        System.out.println(i > 0 ? "踩成功" : "踩失败");
        return "forward:/blog/getByIdBlog?id=" + blog.getBlogId();
    }
}
