package com.Blog.domain;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Blog {

    private Integer blogId; // 博客id
    private Integer userId; // 博客所有者id
    private String blogTitle; // 博客标题
    private String blogContent; // 博客内容
    private String blogDate; // 博客发布时间
    private Integer viewCount; // 博客浏览量
    private Integer blogLikesid; // 博客点赞量
    private Integer blogStepid; // 博客踩量
    private Integer evaluateId; // 博客评论id
    private Integer labelId; // 标签id
    private Integer categoryId; // 分类id

}
