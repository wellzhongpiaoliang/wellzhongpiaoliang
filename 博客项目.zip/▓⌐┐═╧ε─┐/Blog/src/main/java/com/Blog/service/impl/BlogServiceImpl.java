package com.Blog.service.impl;

import com.Blog.domain.Blog;
import com.Blog.domain.Category;
import com.Blog.domain.Evaluate;
import com.Blog.domain.Label;
import com.Blog.mapper.BlogMapper;
import com.Blog.service.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/16 17:20
 */
@Service
public class BlogServiceImpl implements BlogService {
//    自动装配BlogMapper
    @Autowired
    private BlogMapper blogMapper;

    @Override
    public int addBlog(Blog blog) {
        return blogMapper.addBlog(blog);
    }

    @Override
    public int setEvaluateIdInt(Blog blog) {
        return blogMapper.setEvaluateIdInt(blog);
    }

    //    获取前五个博客
    @Override
    public List<Blog> showBlog() {
        return blogMapper.showBlog();
    }

    @Override
    public Label selectByLabelIdLabel(int id) {
        return blogMapper.selectByLabelIdLabel(id);
    }

    @Override
    public List<Evaluate> selectByEvaluateId(int id) {
        return blogMapper.selectByEvaluateId(id);
    }

    @Override
    public int addEvaluateContentInt(Evaluate evaluate) {
        return blogMapper.addEvaluateContentInt(evaluate);
    }

    @Override
    public Category selectByCategoryId(int id) {
        return blogMapper.selectByCategoryId(id);
    }

//    根据博客id获取博客
    @Override
    public Blog selectBlogIdBlog(int id) {
        return blogMapper.selectBlogIdBlog(id);
    }

    @Override
    public List<Blog> selectByTitleAndBlog(String title) {
        return blogMapper.selectByTitleAndBlog(title);
    }

    @Override
    public List<Blog> selectByUserIdAndBlog(int id) {
        return blogMapper.selectByUserIdAndBlog(id);
    }

    @Override
    public List<Blog> selectHotBlog() {
        return blogMapper.selectHotBlog();
    }

//    传入增加后的浏览量和博客id
    @Override
    public int addBlogViewCount(int count, int id) {
        return blogMapper.addBlogViewCount(count, id);
    }

    @Override
    public int setBlog(Blog blog) {
        return blogMapper.setBlog(blog);
    }

}
