package com.Blog.domain;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Step {

  private Integer blogStepid;  //踩id
  private Integer blogStepuserid; // 踩量

}
