package com.Blog.controller;

import com.Blog.domain.Blog;
import com.Blog.domain.Likes;
import com.Blog.domain.User;
import com.Blog.service.BlogService;
import com.Blog.service.LikesService;
import com.Blog.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author 14745
 * @date 2023/10/16 11:47
 */

//用户控制器
@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private BlogService blogService;
    @Autowired
    private LikesService likesService;

    //    登录转主页
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String userLogin(HttpServletRequest request, String email, String pwd) {
        User user = userService.selectByEmailAndPwd(email, pwd);
//        没有数据则返回登录页面
        if (user == null) {
            return "/login";
        }
//        登录成功则存入session
        HttpSession session = request.getSession(true);
        session.setAttribute("USER_SESSION", user);
//        跳转主页
        return "forward:/blog/getBlog";
    }

    //    用户注册
    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    public String addUser(User user, HttpServletRequest request) {
        user.setStatus(0); // 默认权限为普通用户
        Date d = new Date(); // 获取日期
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd"); // 获取日期格式
        String a = df.format(d); // 将日期转为字符串
        user.setIntroduce(a);
        System.out.println("要注册的信息:" + user);
//        先查询邮箱是否已经注册
        User user1 = userService.selectByEmailAndUser(user.getEmail());
        if (user1 != null) {
//            邮箱存在,注册失败,返回登录页面
            return "/login";
        }
//        用户注册
        int i = userService.addUser(user);
        if (i == 0) {
//            注册失败,返回继续注册
            return "/AddUser";
        }
        if (i == 1) {
//            注册成功 存入session
            HttpSession session = request.getSession(true);
            session.setAttribute("USER_SESSION", user);
//        注册成功返回登录页面重新登录
            return "login";
        }
//        意外情况 返回登录页面
        return "login";
    }

    //    退出登录
    @RequestMapping("/exit")
    public String exit(HttpSession session) {
//        删除用户session
        session.removeAttribute("USER_SESSION");
        if (session.getAttribute("USER_SESSION") == null) {
            System.out.println("用户已退出登录");
        } else {
            System.out.println("异常");
        }
//        返回登录页面
        return "login";
    }

    //    个人中心
    @RequestMapping("/userCenter")
    public ModelAndView userCenter(HttpServletRequest request) {
        System.out.println("进入方法");
//        创建一个模型视图
        ModelAndView modelAndView = new ModelAndView();
//        用session获取用户id
        User session = (User) request.getSession().getAttribute("USER_SESSION");
//        根据id获取用户数据
        User user = userService.selectByIdUser(session.getId());
//        获取博客
        List<Blog> blogs = blogService.selectByUserIdAndBlog(user.getId());
        String msg = null;
//        如果该用户没写博客,则返回没有博客
        if (blogs.size() == 0) {
            msg = "您还没有博客";
            modelAndView.addObject("userCenter", user);
            modelAndView.addObject("msg", msg);
            modelAndView.setViewName("UserCenter");
            return modelAndView;
        }
        int like = 0;
        int blogCount = 0;
        ArrayList<Integer> blogcount = new ArrayList<>();
//        累计点赞量
        for (int i = 0; i < blogs.size(); i++) {
            List<Likes> likes = likesService.showLikes(blogs.get(i).getBlogLikesid());
            like += likes.size();
        }
        //        获取浏览最高的博客
        Blog blog = new Blog();
//        获取浏览量
        for (int i = 0; i < blogs.size(); i++) {
            blogcount.add(blogs.get(i).getViewCount());
//            累计浏览量
            blogCount += blogs.get(i).getViewCount();

        }
//        获取最大博客
        Integer max = Collections.max(blogcount);
        for (int i = 0; i < blogs.size(); i++) {
            if (blogs.get(i).getViewCount() == max) {
                blog = blogs.get(i);
            }
        }
//        视图模型装数据
        modelAndView.addObject("msg", msg);
        modelAndView.addObject("blogCount", blogCount);
//        填装浏览最高的博客
        modelAndView.addObject("blog", blog.getBlogTitle());
//        博客总数
        modelAndView.addObject("blogs", blogs.size());
//        用户
        modelAndView.addObject("userCenter", user);
//        总点赞量
        modelAndView.addObject("like", like);
//        视图模型命名
        modelAndView.setViewName("UserCenter");
        return modelAndView;
    }

    //    获取个人信息
    @RequestMapping("/getUserCenter")
    public ModelAndView getBlog(HttpSession session) {
        ModelAndView mod = new ModelAndView();
        User userSession = (User) session.getAttribute("USER_SESSION");
        mod.addObject("user", userSession);
        mod.setViewName("UpUserCenter");
        return mod;
    }

    //    修改个人信息
    @RequestMapping("/setUserCenter")
    public ModelAndView setBlog(User user, HttpServletRequest request) {
        //        用session获取用户id
        User userSession = (User) request.getSession().getAttribute("USER_SESSION");
        ModelAndView modelAndView = new ModelAndView();
        user.setId(userSession.getId());
        if (user.getPhone().length() > 11) {
            modelAndView.addObject("userCenter", userSession);
            modelAndView.setViewName("UserCenter");
            return modelAndView;
        }
        int i = userService.setUserCenter(user);
        System.out.println(i > 0 ? "修改成功" : "修改失败");
        User user1 = userService.selectByIdUser(userSession.getId());
        modelAndView.addObject("userCenter", user1);
//        返回个人中心
        modelAndView.setViewName("UserCenter");
        return modelAndView;
    }

//    用户查询
    @RequestMapping("/selectUser")
    public ModelAndView selectUser(User user) {
        ModelAndView view = new ModelAndView();
        view.setViewName("SelectUser");
        ArrayList<User> users = new ArrayList<>();
//        如果名字不是空的,则是以昵称进行搜索
        if (user.getName() != null) {
//            拼接,模糊查询
            String name = '%' + user.getName() + '%';
            List<User> users1 = userService.selectByNameAndUser(name);
            if (users1 == null){
                return view;
            }
            view.addObject("users", users1);
            return view;
        }
//        如果邮箱不是空的,则是以邮箱进行搜索
        if (user.getEmail() != null) {
            User users2 = userService.selectByEmailAndUser(user.getEmail());
            if (users2==null){
                return view;
            }
            users.add(users2);
            view.addObject("users", users);
            view.setViewName("SelectUser");
            return view;
        }
        return view;
    }

//    帮助中心,等待2.0版本开发
    @RequestMapping("/helpUser")
    public String helpUser() {
        return "redirect:/blog/getBlog";
    }
}
