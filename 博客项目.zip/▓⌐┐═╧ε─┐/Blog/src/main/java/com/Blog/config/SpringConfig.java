package com.Blog.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author 14745
 * @date 2023/10/16 9:08
 */

//定义配置文件
@Configuration
//将MyBatisConfig类和JdbcConfig类交给Spring来管理
@Import({MyBatisConfig.class, JdbcConfig.class})
// 开启包扫描等同于:<context:component-scan base-package="com....">
@ComponentScan("com.Blog.service.impl")
// 开启事务
@EnableTransactionManagement
public class SpringConfig {
}
