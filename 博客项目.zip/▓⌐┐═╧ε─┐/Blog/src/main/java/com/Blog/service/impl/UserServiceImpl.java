package com.Blog.service.impl;

import com.Blog.domain.User;
import com.Blog.mapper.UserMapper;
import com.Blog.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/16 11:45
 */
@Service
public class UserServiceImpl implements UserService {

//    注入UserMapper
    @Autowired
    private UserMapper userMapper;

//    根据邮箱和密码进行登录验证
    @Override
    public User selectByEmailAndPwd(String email, String pwd) {
        return userMapper.selectByEmailAndPwd(email,pwd);
    }

    @Override
    public int addUser(User user) {
        return userMapper.addUser(user);
    }

    @Override
    public User selectByIdUser(int id) {
        return userMapper.selectByIdUser(id);
    }

    @Override
    public User selectByEmailAndUser(String email) {
        return userMapper.selectByEmailAndUser(email);
    }

//    根据昵称查询
    @Override
    public List<User> selectByNameAndUser(String name) {
        return userMapper.selectByNameAndUser(name);
    }

    @Override
    public int setUserCenter(User user) {
        return userMapper.setUserCenter(user);
    }
}
