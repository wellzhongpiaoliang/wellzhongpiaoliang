package com.Blog.service;

import com.Blog.domain.Blog;
import com.Blog.domain.Category;
import com.Blog.domain.Evaluate;
import com.Blog.domain.Label;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/16 17:19
 */
public interface BlogService {


    //    添加博客
    int addBlog(Blog blog);
    //    根据博客id添加评论id
    int setEvaluateIdInt(Blog blog);
    //    查询前五个博客
    List<Blog> showBlog();

    //    根据标签id获取标签
    Label selectByLabelIdLabel(int id);

    //    根据评论id获取评论
    List<Evaluate> selectByEvaluateId(int id);

    //    根据评论id添加评论
    int addEvaluateContentInt(Evaluate evaluate);

    //    根据分类id获取分类
    Category selectByCategoryId(int id);

    //    根据博客id获取博客
    Blog selectBlogIdBlog(int id);
    //    根据博客标题查找博客
    List<Blog> selectByTitleAndBlog(String title);
    //根据用户id获取博客
    List<Blog> selectByUserIdAndBlog(int id);

//    获取热门(浏览量高)博客
    List<Blog> selectHotBlog();

//    增加浏览量
    int addBlogViewCount(int count, int id);

    //    博客修改
    int setBlog(Blog blog);
}
