package com.Blog.controller;

import com.Blog.domain.*;
import com.Blog.service.BlogService;
import com.Blog.service.LabelAndCategoryService;
import com.Blog.service.LikesService;
import com.Blog.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author 14745
 * @date 2023/10/16 16:22
 */

//博客控制器 ,不仅限于博客
@Controller
@RequestMapping("/blog")
public class BlogController {
    @Autowired
    private BlogService blogService;
    @Autowired
    private UserService userService;
    @Autowired
    private LikesService likesService;
    @Autowired
    private LabelAndCategoryService labelAndCategoryService;

    //    主页
    @RequestMapping("/getBlog")
    public ModelAndView getBlog(HttpSession session) {
//        获取登录者信息
        User userSession = (User) session.getAttribute("USER_SESSION");
//        获取博客数据
        List<Blog> blogs = blogService.showBlog();
//        获取标签
        List<String> labels = new ArrayList<>();
//        获取分类
        List<String> categorys = new ArrayList<>();
        for (int i = 0; i < blogs.size(); i++) {
//            循环获取标签
            Label label = blogService.selectByLabelIdLabel(blogs.get(i).getLabelId());
            labels.add(label.getLabelName());
        }
        for (int i = 0; i < blogs.size(); i++) {
//            循环获取分类
            Category category = blogService.selectByCategoryId(blogs.get(i).getCategoryId());
            categorys.add(category.getCategoryName());
        }
//        new时间
        Date d = new Date();
//        获取当前时间的小时,判断时区
        SimpleDateFormat df = new SimpleDateFormat("HH");
        Integer now = Integer.valueOf(df.format(d));
        ModelAndView modelAndView = new ModelAndView();
//        将数据存入ModelAndView
        modelAndView.addObject("blogs", blogs);
        modelAndView.addObject("labels", labels);
        modelAndView.addObject("categorys", categorys);
        modelAndView.addObject("user", userSession);
        modelAndView.addObject("date", now);
        modelAndView.setViewName("main");
        return modelAndView;
    }

    // 修改博客中转控制器
    @RequestMapping("/getLabelAndCategory")
    public ModelAndView getLabelAndCategory() {
        ModelAndView view = new ModelAndView();
//        获取所有标签
        List<Label> labels = labelAndCategoryService.showLabel();
//        获取所有分类
        List<Category> categories = labelAndCategoryService.showCategory();
//        将标签和分类放入视图
        view.addObject("labels", labels);
        view.addObject("categories", categories);
//        视图命名 ,前往<添加博客>
        view.setViewName("AddBlog");
        return view;
    }

//    博客添加
    @RequestMapping("/addBlog")
    public String addBlog(HttpServletRequest request, Blog blog) {
//        获取session
        User userSession = (User) request.getSession().getAttribute("USER_SESSION");
//        获取发布者id
        blog.setUserId(userSession.getId());
//        new一个日期类型
        Date d = new Date();
//        获取当前时间
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
//        将时间转为字符串
        String now = df.format(d);
//        加入发布时间
        blog.setBlogDate(now);
//        将浏览量设置为0
        blog.setViewCount(0);
//        将博客点赞id设置为空
        blog.setBlogLikesid(null);
        //        将博客踩id设置为空
        blog.setBlogStepid(null);
        //        将博客评论id设置为空
        blog.setEvaluateId(null);
//        添加博客的sql
        int i = blogService.addBlog(blog);
//        返回<我的博客>
        return "forward:/blog/myBlog";
    }

    //    带参数到修改博客页面
    @RequestMapping("/setBlog")
    public ModelAndView setBlog(Blog blog) {
        ModelAndView view = new ModelAndView();
//        将传入的博客数据放入视图
        view.addObject("blog", blog);
//        前往<博客修改>
        view.setViewName("SetBlog");
        return view;
    }

    //    修改博客
    @RequestMapping("/setBlog1")
    public String setBlog1(Blog blog) {
//        博客修改
        int i = blogService.setBlog(blog);
//        成功 or 失败
        System.out.println(i > 0 ? "成功" : "失败");
//        返回<我的博客>
        return "forward:/blog/myBlog";
    }


    //    根据id获取博客  博客详情
    @RequestMapping("/getByIdBlog")
    public ModelAndView getByIdBlog(Integer id) {
        ModelAndView view = new ModelAndView();
//        前端传博客id回来进行查询
        Blog blog = blogService.selectBlogIdBlog(id);
//        添加评论id
        if (blog.getEvaluateId() == null) {
            String a = String.valueOf(blog.getBlogId());
            blog.setBlogContent(a);
            int i = blogService.setEvaluateIdInt(blog);
            System.out.println(i > 0 ? "成功" : "失败");
            blog.setBlogLikesid(blog.getBlogId());
            blog.setBlogStepid(blog.getBlogId());
        }
//        添加赞id
        if (blog.getBlogLikesid() == null) {
            int i1 = likesService.setLikesId(blog);
            blog.setBlogLikesid(blog.getBlogId());
            System.out.println(i1 > 0 ? "成功" : "失败");
        }
//        添加踩id
        if (blog.getBlogStepid() == null) {
            int i1 = likesService.setStepId(blog);
            blog.setBlogStepid(blog.getBlogId());
            System.out.println(i1 > 0 ? "成功" : "失败");
        }
//        查询评论
        List<Evaluate> evaluate = blogService.selectByEvaluateId(blog.getBlogId());
        ArrayList<String> list = new ArrayList<>();
//        查询评论用户名
        for (int i = 0; i < evaluate.size(); i++) {
            User user = userService.selectByIdUser(evaluate.get(i).getUserId());
            list.add(user.getName());
        }
        //        查询博客所属人
        User user = userService.selectByIdUser(blog.getUserId());
//        查询标签
        Label label = blogService.selectByLabelIdLabel(blog.getLabelId());
//        查询分类
        Category category = blogService.selectByCategoryId(blog.getCategoryId());
//        查询点赞量
        List<Likes> likes = likesService.showLikes(blog.getBlogLikesid());
        List<Step> steps = likesService.showStep(blog.getBlogStepid());
//       如果存在高并发则需要更优的代码 获取浏览量并且+1
        int sum = blog.getViewCount()+1;
        int i = blogService.addBlogViewCount(sum, blog.getBlogId());
        view.addObject("evaluate", evaluate);
        view.addObject("blog", blog);
        view.addObject("user", user);
        view.addObject("label", label);
        view.addObject("category", category);
        view.addObject("list", list);
        view.addObject("likes", likes.size());
        view.addObject("steps", steps.size());
        view.addObject("sum", sum);
        view.setViewName("blogCenter");
        return view;
    }

    //    添加评论
    @RequestMapping("/addCollect")
    public String addCollect(Evaluate evaluate) {
        int i = blogService.addEvaluateContentInt(evaluate);
//        int sum = blogs.getViewCount() - 1;
//        int i1 = blogService.addBlogViewCount(sum, blogs.getBlogId());
        System.out.println(i > 0 ? "添加成功" : "添加失败");
        return "redirect:getByIdBlog";
    }

//    查找博客控制器
    @RequestMapping("/selectBlog")
    public ModelAndView SelectBlog() {
        ModelAndView view = new ModelAndView();
        view.addObject("msg", 0);
        view.setViewName("SelectBlog");
        return view;
    }

    //    查找博客
    @RequestMapping("/selectBlog1")
    public ModelAndView SelectBlog(Blog blog, String name) {
        ModelAndView view = new ModelAndView();
//        定义一个空博客
        List<Blog> blogs = new ArrayList<>();
//        如果标题不空,则是根据标题搜索
        if (blog.getBlogTitle() != null) {
            blogs = blogService.selectByTitleAndBlog('%' + blog.getBlogTitle() + '%');
            System.out.println("标题查询的博客"+blogs);
        }
//        如果昵称不空,则是根据昵称搜索
        if (name != null) {
            List<User> users = userService.selectByNameAndUser(name);
            for (int i = 0; i < users.size(); i++) {
                blogs.addAll(blogService.selectByUserIdAndBlog(users.get(i).getId()));
            }
        }
//        如果都搜不到则没有这个博客
        if (blogs == null) {
//            返回空
            view.addObject("msg", 0);
            view.setViewName("SelectBlog");
            return view;
        }
//        获取标签
        List<String> labels = new ArrayList<>();
//        获取分类
        List<String> categorys = new ArrayList<>();
        for (int i = 0; i < blogs.size(); i++) {
            Label label = blogService.selectByLabelIdLabel(blogs.get(i).getLabelId());
            labels.add(label.getLabelName());
        }
        for (int i = 0; i < blogs.size(); i++) {
            Category category = blogService.selectByCategoryId(blogs.get(i).getCategoryId());
            categorys.add(category.getCategoryName());
        }
//        装博客数据
        view.addObject("blogs", blogs);
        view.addObject("label", labels);
        view.addObject("category", categorys);
        view.setViewName("SelectBlog");
        return view;
    }

    //    热门博客
    @RequestMapping("/hotBlog")
    public ModelAndView HotBlog() {
        ModelAndView view = new ModelAndView();
//        获取博客
        List<Blog> blogs = blogService.selectHotBlog();
        //        获取标签
        List<String> labels = new ArrayList<>();
//        获取分类
        List<String> categorys = new ArrayList<>();
        for (int i = 0; i < blogs.size(); i++) {
            Label label = blogService.selectByLabelIdLabel(blogs.get(i).getLabelId());
            labels.add(label.getLabelName());
        }
        for (int i = 0; i < blogs.size(); i++) {
            Category category = blogService.selectByCategoryId(blogs.get(i).getCategoryId());
            categorys.add(category.getCategoryName());
        }
        view.addObject("blogs", blogs);
        view.addObject("labels", labels);
        view.addObject("categorys", categorys);
        view.setViewName("HotBlog");
        return view;
    }

    //    我的博客
    @RequestMapping("/myBlog")
    public ModelAndView myBlog(HttpServletRequest request) {
        ModelAndView view = new ModelAndView();
//        获取session
        User user = (User) request.getSession().getAttribute("USER_SESSION");
//        获取博客
        List<Blog> blogs = blogService.selectByUserIdAndBlog(user.getId());
        String msg = null;
//        如果该用户没写博客,则返回没有博客
        if (blogs.size() == 0) {
            msg = "您还没有博客";
            view.addObject("msg", msg);
            view.setViewName("MyBlog");
            return view;
        }
        //        获取标签
        List<String> labels = new ArrayList<>();
//        获取分类
        List<String> categorys = new ArrayList<>();
        for (int i = 0; i < blogs.size(); i++) {
            Label label = blogService.selectByLabelIdLabel(blogs.get(i).getLabelId());
            labels.add(label.getLabelName());
        }
        for (int i = 0; i < blogs.size(); i++) {
            Category category = blogService.selectByCategoryId(blogs.get(i).getCategoryId());
            categorys.add(category.getCategoryName());
        }
        view.addObject("blogs", blogs);
        view.addObject("labels", labels);
        view.addObject("categorys", categorys);
        view.setViewName("MyBlog");
        return view;
    }
}
