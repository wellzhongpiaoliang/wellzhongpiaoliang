package com.Blog.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Evaluate {

    private Integer evaluateId; // 评论id
    private Integer blogId; //博客id
    private String evaluateContent;  //评论内容
    private Integer userId;  // 评论者id
}
