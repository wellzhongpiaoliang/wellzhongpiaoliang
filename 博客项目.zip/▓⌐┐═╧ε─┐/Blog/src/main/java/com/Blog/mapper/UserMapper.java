package com.Blog.mapper;

import com.Blog.domain.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author 14745
 * @date 2023/10/16 11:38
 */
public interface UserMapper {

//    登录验证
    User selectByEmailAndPwd(@Param("email") String email,@Param("pwd") String pwd);

//    用户注册
    int addUser(User user);

//    根据id获取用户数据
    User selectByIdUser(int id);

//    根据邮箱获取用户信息
    User selectByEmailAndUser(String email);

//    根据昵称查询用户信息
    List<User> selectByNameAndUser(String name);

//    修改用户信息
    int setUserCenter(User user);
}
