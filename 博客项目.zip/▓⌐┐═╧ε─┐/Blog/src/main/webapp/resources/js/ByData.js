﻿function main() {
    console.log("页面加载时执行此方法....");
    $.ajax({
        url: "${pageContext.request.contextPath}/blog/getBlog", //要请求的后端地址
        contentType: "application/x-www-form-urlencoded;charset=UTF-8",
        dataType: "json", //后端返回的数据格式
        success: function (result) {//ajax请求成功后触发的方法
            console.log(result); //result为响应内容
        },
        error: function () {//ajax请求失败后触发的方法
            console.log('失败');
        }
    });
}

function title01(blogId){
    console.log("点击了博客")
    let url ="/blog/getByIdBlog?id="+blogId;
    window.location.href = url;
    // window.location.replace(url)
}
